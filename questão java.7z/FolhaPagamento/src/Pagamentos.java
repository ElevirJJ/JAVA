public class Pagamentos {
    String nome;
    double salario;
    double matricula;






}
