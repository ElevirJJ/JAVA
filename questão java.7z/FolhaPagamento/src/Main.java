import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Pagamentos folha = new Pagamentos();

        System.out.println("dados do colaborador Elevir");
        System.out.println("matricula: ");
        folha.matricula = scanner.nextDouble();

        scanner.nextLine();

        System.out.println("nome completo: ");
        folha.nome = scanner.nextLine();

        System.out.println("salario bruto: ");
        folha.salario = scanner.nextDouble();


        //calulos salarios

        double inss = folha.salario * 15;
        double liquido = inss - folha.salario;


        System.out.println(" matricula:" + folha.matricula);
        System.out.println("nome completo: " + folha.nome);
        System.out.println("salario bruto: " + folha.salario);
        System.out.println("Dedução INSS: " + liquido);
        System.out.println("Salario Liquido: " + liquido);


    }
}