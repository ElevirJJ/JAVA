public class Notas {
    String nome;

    double nota1;
    double nota2;
    double nota3;

    double media;






}
