import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        Pessoa p = new Pessoa();


        System.out.println("digite sua idade antiga:");
        p.idade = s.nextInt();


        System.out.println("antiga:"+p.idade);
        p.niver();

        System.out.println("atual:"+p.idade);


    }
}

