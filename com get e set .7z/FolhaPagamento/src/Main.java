import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Pagamentos folha = new Pagamentos();

        System.out.println("dados do colaborador Elevir");
        System.out.println("matricula: ");
        folha.setMatricula(scanner.nextDouble());
        System.out.println(folha.getMatricula());

        scanner.nextLine();

        System.out.println("nome completo: ");
        folha.setNome(scanner.nextLine());
        System.out.println(folha.getNome());

        System.out.println("salario bruto: ");
        folha.setSalario(scanner.nextDouble());
        System.out.println(folha.getSalario());


        //calulos salarios

        double inss = folha.getSalario() * 15;
        double liquido = folha.getSalario() - inss;


        System.out.println(" matricula:" + folha.getMatricula());
        System.out.println("nome completo: " + folha.getNome());
        System.out.println("salario bruto: " + folha.getSalario());
        System.out.println("Dedução INSS: " + inss);
        System.out.println("Salario Liquido: " + liquido);


    }
}