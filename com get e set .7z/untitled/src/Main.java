
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Aluno a = new Aluno();
        Coordenador c = new Coordenador();


        System.out.println("digite o nome: ");
        a.setNome(scanner.nextLine());
        System.out.println(a.getNome());

        System.out.println("nome do coordenandor: ");
        c.setMatricula(scanner.nextLine());
        System.out.println(c.getMatricula());

    }
}