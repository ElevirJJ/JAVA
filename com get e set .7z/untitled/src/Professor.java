public class Professor {
}
