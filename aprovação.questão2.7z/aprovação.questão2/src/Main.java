import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Notas n = new Notas();

        System.out.println("solicito um nome: ");
        n.nome = scanner.next();

        System.out.println("solicito uma nota: ");
        n.nota1 = scanner.nextDouble();

        System.out.println("solicito uma segunda nota: ");
        n.nota2 = scanner.nextDouble();

        System.out.println("solicito uma terceira nota: ");
        n.nota3 = scanner.nextDouble();

        n.media = (n.nota1+n.nota2+n.nota3)/ 3;
        System.out.println(n.media);

        if (n.media >= 70) {
            System.out.println("Aprovado");
        } else if (n.media < 40) {
            System.out.println("Reprovado");
        } else{
            System.out.println("Final");

        }
    }

}
