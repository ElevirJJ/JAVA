import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        int i = 0;
        String sair = "";

        //Teclado
        Scanner scanner = new Scanner(System.in);
        CadastroPessoa cp = new CadastroPessoa();
        PessoaFisica pessoaFisica = new PessoaFisica();
        PessoaJuridica pessoaJuridica = new PessoaJuridica();

        while (!sair.equals("N")){
            Pessoa p = new Pessoa();
            System.out.println("Digite o nome da pessoa a ser cadastrada:");
            p.setNome(scanner.next());
            System.out.println("Digite a idade da pessoa a ser cadastrada:");
            p.setIdade(scanner.nextInt());
            scanner.nextLine();

            //Pessoa Fisica
            System.out.println("Digite o nome da pessoa física:");
            pessoaFisica.setNome(scanner.next());
            System.out.println("Digite a idade da pessoa física:");
            pessoaFisica.setIdade(scanner.nextInt());

            cp.cadastrarPessoa(pessoaFisica);
            System.out.println(pessoaFisica);


            //Pessoa Juridica
            System.out.println("Digite o nome da pessoa juridica:");
            pessoaJuridica.setCnpj(scanner.next());
            System.out.println("Digite a idade da pessoa juridica:");
            pessoaJuridica.setCnpj(scanner.next());

            cp.cadastrarPessoa(pessoaJuridica);
            System.out.println(pessoaJuridica);


            cp.cadastrarPessoa(p);
            System.out.println("deseja repetir?" + "S/N");
            sair = scanner.nextLine();
        }
        cp.listar();;
    }
}