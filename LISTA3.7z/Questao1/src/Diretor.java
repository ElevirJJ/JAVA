public class Diretor extends Funcionario{
    private int acoes;

    public Diretor(String nome, double salario,int acoes){
        super(nome, salario);
        this.acoes = acoes;
    }
    public double calcularbonus(){
        return 0.15 * salario;
    }
    public void exibirDiretor(){
        super.exibir();
        System.out.println("Ações: " + acoes);
    }

}
