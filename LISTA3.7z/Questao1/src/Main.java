import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Cadastro de Gerente ");
        System.out.println("Nome: ");
        String nomeGerente = scanner.nextLine();
        System.out.println("salario: ");
        double salario = scanner.nextDouble();

        scanner.nextLine();

        System.out.println("Departamento");
        String departamento = scanner.nextLine();

        Gerente gerente = new Gerente(nomeGerente, salario, departamento);

        System.out.println("\nCadastro de Diretor:");
        System.out.print("Nome: ");
        String nomeDiretor = scanner.nextLine();
        System.out.print("Salário: ");
        double salarioDiretor = scanner.nextDouble();
        System.out.print("Quantidade de Ações: ");
        int acoesDiretor = scanner.nextInt();

        Diretor diretor = new Diretor(nomeDiretor, salarioDiretor, acoesDiretor);

        System.out.println("\nDados do Gerente:");
        gerente.exibirGerente();
        System.out.println("Bônus do Gerente: " + gerente.calcularBonus());

        System.out.println("\nDados do Diretor:");
        diretor.exibirDiretor();
        System.out.println("Bônus do Diretor: " + diretor.calcularBonus());

        scanner.close();


    }
}