public class Smartphone extends Produtos{
    private  int ligacao;
    private int ligar;

    public double getligaçao() {
        return ligacao;
    }

    public void setLigacao(int ligacao) {
        this.ligar = ligacao;
    }

    public void ligacao(){
        ligar = 4 * 4;

    }
    public int getDinheiro(){
        return ligar;
    }

}