import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        //chamando teclado
        Scanner scanner = new Scanner(System.in);

        Produtos p = new Produtos();
        Televisao t = new Televisao();
        Smartphone s = new Smartphone();

        //produtos
        System.out.println("nome do produto: ");
        p.setNome(scanner.nextLine());
        System.out.println(p.getNome());

        System.out.println("nome do segundo produto: ");
        p.setNome(scanner.nextLine());
        System.out.println(p.getNome());

        System.out.println("quantos tem em estoque de tv" + "?");
        p.setEstoque(scanner.nextDouble());
        System.out.println(p.getEstoque());

        System.out.println("quantos tem em estoque smartphone" + "?");
        p.setEstoque(scanner.nextDouble());
        System.out.println(p.getEstoque());

        System.out.println("qual é o preço da televisão " + "?");
        double tv = scanner.nextDouble();

        System.out.println("qual é o preço do smartphone " + "?");
        double celular = scanner.nextDouble();

        System.out.println("quantos canais tem a tv" + "?");
        t.acessarcanais();
        System.out.println(t.getCanais());


        System.out.println("quantas ligações possue esse celular" + "?");
        s.setLigacao(scanner.nextInt());
        System.out.println(s.getligaçao());

        s.ligacao();
        System.out.println(s.getligaçao());

        scanner.close();
    }
}