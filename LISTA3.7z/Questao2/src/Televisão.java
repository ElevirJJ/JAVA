public class Televisão extends Produtos {

    private int tv;

    public void acessarCanais() {

    }

    public int getTv() {
        return tv;

    }

}
