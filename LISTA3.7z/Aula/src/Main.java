import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        //chamando teclado
        Scanner scanner = new Scanner(System.in);
        Pessoa jp = new Pessoa();
        Aluno a = new Aluno();
        Professor p = new Professor();

        System.out.println("Digite 1 para cadrastar um aluno: ");
        System.out.println("Digite 2 para cadrastar um professor: ");
        int opção = scanner.nextInt();
        switch (opção) {
            case 1:
                System.out.println("Primeira nota: ");
                a.setNota1(scanner.nextDouble());
                System.out.println(a.getNota1());

                System.out.println("Segunda nota: ");
                a.setNota2(scanner.nextDouble());
                System.out.println(a.getNota2());

                System.out.println("Terceira nota: ");
                a.setNota3(scanner.nextDouble());
                System.out.println(a.getNota3());

                a.calcularMedia();
                System.out.println(a.getMedia());
                break;

            case 2:
                System.out.println("Salário do professor é: ");
                p.setSalario(scanner.nextDouble());
                System.out.println(p.getSalario());

                p.calcularSalario();
                System.out.println(p.getDinheiro());

        }
        
    }
}