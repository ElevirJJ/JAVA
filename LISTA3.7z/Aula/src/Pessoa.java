public class Pessoa {
   private System nome;
   private int idade;

    public System getNome() {
        return nome;
    }

    public void setNome(System nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public class aniversario{

    }
}
