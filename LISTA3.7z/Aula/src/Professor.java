public class Professor extends Pessoa{
  private  double salario;
  private double dinheiro;

  public double getSalario() {
    return salario;
  }

  public void setSalario(double salario) {
    this.salario = salario;
  }

  public void calcularSalario(){
    dinheiro = (salario) * 2;

    }
    public double getDinheiro(){
      return dinheiro;
    }

}
