import java.util.Scanner;

public class CalculadoraMain {
    public static void main(String[]args){
        int numero ;

        Calculadora c = new Calculadora();
        Scanner sc = new Scanner(System.in);


        System.out.println("numero1:");
        c.n1 = sc.nextInt();
        System.out.println("numero2:");
        c.n2 = sc.nextInt();
        System.out.println("digite a operação");
        System.out.println("1- multilicar");
        System.out.println("2 - dividir ");
        System.out.println("3 - somar");
        System.out.println("4 - subtrair");
        numero = sc.nextInt();



         switch (numero){

             case 1:
                System.out.println("Multiplica o numero:");
                c.multiplicar();
             break;

             case 2:
                System.out.println("dividir o numero:");
                c.dividir();
             break;

             case 3:
                 System.out.println("somar o numero:");
                 c.somar();
              break;

             case 4:
                 System.out.println("subtrair o numero:");
                 c.subtrair();
             break;

             default:
                 System.out.println("invalido");



            }

    }
}

