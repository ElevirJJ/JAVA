public  interface Voar {
    public void vooo();

}
