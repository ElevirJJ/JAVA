public class Cachorro extends Animal implements Terrestre{
    public Cachorro(String nome){
        super(nome);
    }

    @Override
    public void emetirsom() {
        System.out.println("auau");
    }

    @Override
    public void corrida() {
        System.out.println("cachorro correndo ");
    }
}
