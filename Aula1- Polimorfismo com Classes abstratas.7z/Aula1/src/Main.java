public class Main {
    public static void main(String[] args) {

        Cachorro cachorro = new Cachorro("toto");
        Gato gato = new Gato("bichano");
        Passarinho passarinho2 = new Passarinho("tec");

        System.out.println(gato.getNome());
        gato.emetirsom();
        cachorro.emetirsom();
        cachorro.corrida();






        Animal passarinho = new Passarinho("tectec");
        Animal cachorro2 = new Cachorro("toto");
        passarinho.emetirsom();
        ((Passarinho) passarinho).vooo();
        cachorro.emetirsom();
        ((Cachorro)cachorro2).corrida();


        
        Poli p =new Poli();
        p.chamar_corrida(cachorro);
        p.chamar_corrida(gato);
        p.chamarvooo(passarinho2);


    }
}