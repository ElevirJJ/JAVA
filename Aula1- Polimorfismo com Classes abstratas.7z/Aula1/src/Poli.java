public class Poli {
    public void chamar_som (Animal animal){
        animal.emetirsom();
    }

    public void chamar_corrida(Terrestre terrestre){
        terrestre.corrida();
    }

    public void chamarvooo(Voar voar){
        voar.vooo();
    }
}
