public class Gato extends Animal implements Terrestre {
    public Gato(String nome){
        super(nome);
    }

    @Override
    public void emetirsom() {
        System.out.println("miau");
    }

    @Override
    public void corrida() {
        System.out.println("o gato esta correndo");
    }
}
