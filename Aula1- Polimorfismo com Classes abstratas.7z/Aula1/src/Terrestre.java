public interface Terrestre {
    public void corrida();
}
