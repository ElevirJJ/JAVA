public class Passarinho extends Animal implements Voar {
    public Passarinho(String nome){
        super(nome);
    }

    @Override
    public void emetirsom() {
        System.out.println("canta");
    }

    @Override
    public void vooo() {
        System.out.println("passaro voando");
    }
}
